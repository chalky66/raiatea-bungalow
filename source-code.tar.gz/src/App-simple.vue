<template>
  <div class="min-h-screen bg-gray-50 p-8">
    <h1 class="text-4xl font-bold text-center">Vue App is Working!</h1>
    <p class="text-center mt-4">If you can see this, Vue is loaded correctly.</p>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>